KTP REVIEWED ASSETS

This pack contains labelled visualization previews, a QA review, and corrected ASF metadata exports.

Important: the data difference remains EXPLORATORY. Both QA summary CSVs report FAIL for the aggregate identification group check. Do not use this as a flood/crop-damage/river-depth classification.

For integration, prefer:
- visualizations/KTP_BEFORE_LABELLED.png
- visualizations/KTP_AFTER_LABELLED.png
- visualizations/KTP_CHANGE_LABELLED_EXPLORATORY.png
- metadata/KTP_NISAR_GRANULES_CORRECTED.csv
- metadata/KTP_NISAR_GRANULE_DETAILS_CORRECTED.json
- metadata/KTP_NISAR_GRANULES_CORRECTED.geojson
- qa/KTP_QA_CHECKS_CONSOLIDATED.csv
- qa/KTP_QA_OVERVIEW.csv
- documentation/KTP_DELIVERABLES_REVIEW.md

The large original NISAR science HDF5 files were not included or downloaded.
