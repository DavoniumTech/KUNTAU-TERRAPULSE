KUNTAU TERRAPULSE — LOCAL NISAR OUTPUTS

STATUS: EXPLORATORY. Do not describe this as a validated flood map, crop-health map, flood prediction or river-depth product.

INPUT OBSERVATIONS
8 Oct 2026: NISAR_L2_PR_GCOV_032_123_D_083_2005_SHSH_A_20261008T175433_20261008T175508_P05023_N_F_J_001 (SHSH)
20 Oct 2026: NISAR_L2_PR_GCOV_033_123_D_083_2005_DHDH_A_20261020T175433_20261020T175508_P05023_N_F_J_001 (DHDH)
Common measurement extracted: Frequency-A HHHH, Band 1 from the supplied GeoTIFFs.

GRID CHECK
327 x 332 pixels; EPSG:32632; 20 m pixels; identical geotransform and projection.
Common alpha-valid pixels: 108555 of 108564.

VISUALIZATIONS
Before/after previews use the same pooled 2nd–98th percentile display stretch. Display copies are for visual presentation only.
Change preview uses blue for negative (after lower than before), pale neutral near zero, red for positive (after higher than before). This is a continuous measurement-difference display, not a cause classification.

SCIENTIFIC CAUTION
The source acquisition modes differ (SHSH vs DHDH). Although the shared Frequency-A HHHH channel was extracted, QA reports and product-level comparability must be reviewed before environmental interpretation. Radar returns can respond to multiple surface and geometry factors. Ground observations and independent evidence are required.

OUTPUTS
01_VISUALIZATIONS: PNG previews
02_RASTERS: georeferenced RGB display GeoTIFFs and Float32 exploratory difference GeoTIFF
03_METADATA: analysis JSON/CSV, ASF catalogue records (when present), GDAL audit reports
04_QA: downloaded QA PDFs/CSVs/XML/quicklook PNGs (when present)

Processing was run locally. This script makes no network requests and downloads no files.
